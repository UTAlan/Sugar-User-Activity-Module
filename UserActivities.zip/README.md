# Sugar User Activity Module
Installs a custom module in SugarCRM that allows you to view all Activities in a single List View.

## Release Notes
**1.0.0 (2015-03-17)** - Initial release.

## Known Issues
* Adding "Module", "Related Module", or "Related Name" to Search layout works, but searching by these fields results in 0 records returned.

## Feature Requests
* Compatibility with Sugar 7
* Compatibility with Reports module
